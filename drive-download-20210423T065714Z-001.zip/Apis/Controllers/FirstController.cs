﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tobedeleted.Controllers
{
    /// <summary>
    /// This is the First Controller. A Cheatsheet to WebApi action flavours
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class FirstController : ControllerBase
    {
        [HttpGet]   //api/First/tryroute
        [Route("tryroute")]
        public string[] Get() {
            return new string[] { "Eena", "Meena", "Deeka", "Cheeka" };
        }

        [HttpGet("covidregions")] //localhost:<port>/api/First/covidregions
        public List<string> GetPlaces()
        {
            return new List<string>() { "Pune", "Mumbai", "Delhi", "Bangalore" };
        }

        [HttpGet("usingActionSimple")]
        public IActionResult GetPlacesUsingActionResult() {
            return Ok(new List<string>() { "Pune", "Mumbai", "Delhi", "Bangalore" });
        }

        [HttpGet("usingAction")]
        [ProducesDefaultResponseType()]
        [ProducesResponseType(200)]
        public List<string> GetPlacesUsingAttributes()
        {
            return new List<string>() { "Pune", "Mumbai", "Delhi", "Bangalore" };
        }

        [HttpGet("asynch")]
        public async Task<string> GetPlacesAsync() {

            string result = await Task.Run(() => "A continuous message");
            return result;
        }

        [HttpGet("json")]
        public JsonResult GetPlacesJson() {
            return new JsonResult(new List<string>() { "Pune", "Mumbai", "Delhi", "Bangalore" });
        }

        [HttpGet("getsingle/{placeId}")]    //=> RouteParam  getsingle/1001, getsingle?speciality=""
        public string GetSinglePlace([FromRoute] string placeId, [FromQuery] string speciality)
        {
            return $"{placeId} is known for {speciality}";
        }

        [HttpPost("{msg}")]
        public IActionResult Post([FromBody] WeatherForecast pforecast, [FromRoute] string msg) {
                           //  https                  ://     localhost:<port>           + /api/First/Greetings
            return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/", 
                           pforecast);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeBL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tobedeleted.Controllers
{
    /// <summary>
    /// A practical Employee management API
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployeeRepository _empRepo;
        public EmployeesController(IEmployeeRepository empRepo)
        {
            _empRepo = empRepo;
        }

        /// <summary>
        /// Gets all the employees in the company
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Get() {
            return Ok(_empRepo.GetEmployees());
        }

        /// <summary>
        /// Gets details for a selected employee id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")] //https://5001/api/employees/1234-24546
        public IActionResult GetDetail([FromRoute] Guid id) {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Adds a new employee to the company
        /// </summary>
        /// <param name="pEmployee"></param>
        /// <returns></returns>
        [HttpPost("addemployee")]
        public IActionResult AddEmployee(EmployeeVM pEmployee) {

            EmployeeVM tempEmp =_empRepo.GetEmployees().Where((e) => e.Email == pEmployee.Email).FirstOrDefault();

            if (tempEmp != null)
            {
                ModelState.AddModelError("Duplicate", "The employee entry exists");
                return BadRequest(ModelState);
            }

            _empRepo.AddEmployee(pEmployee);
            return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/" + pEmployee.EmployeeId, pEmployee);

        }

        [HttpPut("Edit")]
        public IActionResult EditEmployee([FromBody] EmployeeVM pEmployee) {
            throw new NotImplementedException();
        }

        [HttpDelete("Delete/{id}")]
        public IActionResult RemoveEmployee([FromRoute] Guid id) {
            throw new NotImplementedException();
        }

    }
}

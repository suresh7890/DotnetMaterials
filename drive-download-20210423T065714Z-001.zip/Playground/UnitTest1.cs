using PlaygroundSource;
using System;
using System.Collections.Generic;
using Xunit;

namespace Playground
{
    public class UnitTest1
    {
        [Fact]
        public void Test_AddMethod()
        {
            //Arrange
            int n1 = 100;
            int n2 = 200;
            int expected = 300;

            //Act
            int result = Add(n1, n2);

            //Assert
            Assert.Equal(expected, result);
            Assert.Equal<int>(expected, result);
        }

        private int Add(int n1, int n2)
        {
            return n1 + n2;
        }

        [Theory]
        [InlineData(100, 200, -100)]
        [InlineData(-100, -200, 100)]
        [InlineData(500, -200, 700)]
        public void Test_SubMethod(int n1, int n2, int expected)
        {
            
            //Act
            int result = Subtract(n1, n2);

            //Assert
            Assert.Equal(expected, result);
            Assert.Equal<int>(expected, result);
        }

        private int Subtract(int n1, int n2)
        {
            return n1 - n2;
        }

        [Fact(Skip ="To be done in Sprint 10")]
        [Trait("Sprint 10", "For Future SquareRoot Implementation")]
        public void Test_SquareRoot()
        {
            Assert.True(true);
        }

        public void NormalMethod() { }

        [Fact]
        public void Test_Playground_GetStrings()
        {
            //Act
            Simple objSimple = new Simple();
            List<string> result =objSimple.GetStrings();    //{'Eena', 'Meena', 'Deeka'}

            //Assert
            Assert.NotNull(result); //result should not be null
            Assert.NotEmpty(result); //Count > 0
            //Every item is expected to contain the letter 'a'
            Assert.All<string>(result, (str) => Assert.Contains('a', str));
            Assert.All<string>(result, (str) => Assert.EndsWith("a", str));
            
        }

        [Theory]
        [InlineData("sana@danske.com",true)]
        [InlineData("sana-danske.com", false)]
        public void Test_IsValidAddress(string email, bool expectedOutput) {
        
        }
    }
}

﻿using EmployeeBL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Text;
using tobedeleted.Controllers;
using Xunit;

namespace Assertions
{
    public class TestApi
    {
        IEmployeeRepository repository;
        public TestApi()
        {
            
           
        }

        [Fact]
        public void Task_GetPostById_Return_OkResult()
        {
            //Arrange
            IEmployeeRepository repository = new MockEmployeeRepo();
            var controller = new EmployeesController(repository);
            

            //Act
            var data = controller.Get();

            //Assert
            Assert.IsType<OkObjectResult>(data);
        }
    }

    //public class DummyDataDBInitializer
    //{
    //    public DummyDataDBInitializer()
    //    {
    //    }

    //    public void Seed(EmpDBContext context)
    //    {
    //        context.Database.EnsureDeleted();
    //        context.Database.EnsureCreated();

    //        context.Employees.AddRange(
    //            new Employee() { Name = "Eena", Id=1 },
    //            new Employee() { Name = "Meena", Id = 2 },
    //            new Employee() { Name = "Teena", Id = 3 },
    //            new Employee() { Name = "Beena", Id = 4 }
    //        );

         
    //        context.SaveChanges();
    //    }
    //}
}

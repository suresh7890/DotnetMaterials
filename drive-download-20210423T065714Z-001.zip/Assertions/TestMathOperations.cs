using MathOps;
using System;
using Xunit;

namespace Assertions
{
    public class MathOperationTest
    {
        [Fact]
        public void Task_Add_TwoNumber()
        {
            // Arrange  
            var num1 = 2.9;
            var num2 = 3.1;
            var expectedValue = 6;

            // Act  
            var sum = MathOperation.Add(num1, num2);

            //Assert  
            Assert.Equal(expectedValue, sum, 1);
        }

        [Theory]
        [InlineData(2.9, 3.1, -0.2)]
        [InlineData(5,4, 1)]
        [InlineData(-5.1, 3.1, -8.2)]
        public void Task_Subtract_TwoNumber(double num1, double num2, double expectedValue)
        {
            // Arrange  
            //var num1 = 2.9;
            //var num2 = 3.1;
            //var expectedValue = -0.2;

            // Act  
            var sub = MathOperation.Subtract(num1, num2);

            //Assert  
            Assert.Equal(expectedValue, sub, 1);
        }

        [Fact(DisplayName = "Multifunctional")]
        [Trait("Math and Algebra", "For 2 numbers or variables")]
        public void Task_Multiply_TwoNumber()
        {
            // Arrange  
            var num1 = 2.9;
            var num2 = 3.1;
            var expectedValue = 8.99;

            // Act  
            var mult = MathOperation.Multiply(num1, num2);
            
            //Assert  
            Assert.Contains("9", num1.ToString());
            Assert.Equal(expectedValue, mult, 2);
        }

        [Theory]
        [InlineData(2.9, 3.1, 0.94)]
        [InlineData(5, 5, 1)]
        public void Task_Divide_TwoNumber(double num1, double num2, double expectedValue)
        {
            // Arrange  
            //var num1 = 2.9;
            //var num2 = 3.1;
            //var expectedValue = 0.94; //Rounded value  

            // Act  
            var div = MathOperation.Divide(num1, num2);

            //Assert  
            Assert.Equal(expectedValue, div, 2);
        }

        [Fact]
        public void Task_Divide_By_Zero()
        {
            var num1 = 2.9;
            var num2 = 0;
            

            // Act  
            Assert.Throws<DivideByZeroException>(()=> MathOperation.Divide(num1, num2));

            //Assert  
        }

        [Fact(Skip ="Part of phase 2 release")]
        public void Task_SquareRoot() { }
    }
}

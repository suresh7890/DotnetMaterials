﻿using Ops;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Assertions
{
    public class TestMailManager
    {
        [Fact]
        public void ValidEmail()
        {
            //Arrange
            var mailManager = new MailManager();
            const string mailAddress = "meena.kumar@company.com";

            //Act
            bool isValid = mailManager.IsValidAddress(mailAddress);

            //Assert
            Assert.True(isValid, $"The email {mailAddress} is not valid");
        }

        [Fact]
        public void NotValidEmail()
        {
            //Arrange
            var mailManager = new MailManager();
            const string mailAddress = "beena.smith.company.com";

            //Act
            bool isValid = mailManager.IsValidAddress(mailAddress);

            //Assert
            Assert.False(isValid, $"The email {mailAddress} is valid, but it shouldn’t");
        }
    }
}

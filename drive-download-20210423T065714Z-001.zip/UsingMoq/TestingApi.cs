﻿using EmployeeBL;
using System;
using System.Collections.Generic;
using System.Text;
using tobedeleted.Controllers;
using Xunit;

namespace UsingMoq
{
   public class TestingApi
    {
        Moq.Mock<IEmployeeRepository> mock = new Moq.Mock<IEmployeeRepository>();
        Moq.Mock<IEmployeeRepository> mockEmpRepo = new Moq.Mock<IEmployeeRepository>();

        [Fact]
        public void Task_GetEmployees()
        {
            mock.Setup(repo => repo.GetEmployees()).Returns
                (() => new List<EmployeeVM>()
                    {
                        new EmployeeVM(){Name="Meena", Department="Engg", Email="meena@gmail.com", EmployeeId=new Guid()}
                    }
                );
            mock.Object.GetEmployees();
            mock.Verify((m) => m.GetEmployees(), Moq.Times.Once);
        }

        [Fact]
        public void Task_AddDependency_ToEmpController() {
            EmployeesController empController = new EmployeesController(mockEmpRepo.Object);
            Assert.IsAssignableFrom<IEmployeeRepository>(mockEmpRepo.Object);
            Assert.NotNull(mockEmpRepo.Object);
            Assert.NotNull(empController);
            Assert.IsType<EmployeesController>(empController);
        }
    }
}

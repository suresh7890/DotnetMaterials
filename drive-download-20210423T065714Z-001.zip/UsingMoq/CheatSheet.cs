using Ops;
using System;
using Xunit;

namespace UsingMoq
{
    public class CheatSheet
    {
        Moq.Mock<IFoo> mock = new Moq.Mock<IFoo>();

        [Fact]
        public void Test_Interface_DoSomething()
        {
            //setup the mock, creating a behavior similar to dosomething
            //coz, DoSomething() returns a boolean, our mock will also return a boolean expectation

            mock.Setup(objFoo => objFoo.DoSomething(Moq.It.IsNotNull<string>()))
                                       .Returns(() => { Console.WriteLine("Done Something"); return true; });
            mock.Verify();

        }

        [Fact]
        public void Test_Interface_OutArgs()
        {
            string theOutParam = "An out param";
            mock.Setup(objfoo => objfoo.TryParse("Writing my first test", out theOutParam)).Returns(true);
        }

        [Fact]
        public void Test_Interface_Refs()
        {
            //creating an instance of the class
            var instance = new Bar();

            //Mock setup
            mock.Setup(objFoo => objFoo.Submit(ref instance)).Returns(true);
        }

        [Fact]
        public void Test_Interface_Arguments()
        {
            mock.Setup(objFoo => objFoo.DoSomethingStringy(Moq.It.IsAny<string>())).Returns((string s) => s.ToLower());
            mock.Setup(objFoo => objFoo.DoSomething(Moq.It.IsInRange(18, 99, Moq.Range.Inclusive), Moq.It.IsNotNull<string>())).CallBase();
        }


        [Fact]
        public void Test_Interface_Throw_Exceptions()
        {
            mock.Setup(objFoo => objFoo.DoSomething(Moq.It.IsRegex("<script>.*</script>", System.Text.RegularExpressions.RegexOptions.Multiline))).Throws<InvalidOperationException>();
        }

        [Fact]
        public void Test_Interface_LazyEval()
        {
            int count = 10;
            //straight forward evaluation
            mock.Setup(objFoo => objFoo.GetCount()).Returns(count);

            //lazy evaluation using delegate / anonymous functions / lambdas
            mock.Setup(objFoo => objFoo.GetCount()).Returns(() => count);
        }


        [Fact]
        public void Test_Interface_LazyEval_Returns_DifferentValues()
        {
            int count = 10;
            //lazy evaluation using delegate / anonymous functions / lambdas
            mock.Setup(objFoo => objFoo.GetCount()).Returns(() => count)
                                                    .Callback(() => count++);
            Console.WriteLine(mock.Object.GetCount());
        }
    }
}

﻿using System;

namespace MathOps
{
    public static class MathOperation
    {
        public static double Add(double number1, double number2)
        {
            return (number1 + number2);
        }

        public static double Subtract(double number1, double number2)
        {
            return (number1 - number2);
        }

        public static double Multiply(double number1, double number2)
        {
            return (number1 * number2);
        }

        public static double Divide(double number1, double number2)
        {
            if (number2 == 0)
            {
                throw new DivideByZeroException();
            }
            return (number1 / number2);
        }
    }
}

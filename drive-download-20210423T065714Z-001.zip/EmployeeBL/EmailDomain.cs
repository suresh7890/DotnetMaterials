﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EmployeeBL
{
    public class EmailDomain : ValidationAttribute
    {
        public string DomainName { get; set; }

        public override bool IsValid(object value)
        {
            //[0]  [1]
            //abc@danske.com
            if(String.IsNullOrEmpty(value.ToString()))
                return base.IsValid(value);

            string domainPart = value.ToString().Split('@')[1];

            return domainPart.ToLower() == DomainName.ToLower();
            
        }
    }
}

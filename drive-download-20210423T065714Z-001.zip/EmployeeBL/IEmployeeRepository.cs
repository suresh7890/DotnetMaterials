﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeBL
{
    public interface IEmployeeRepository
    {
      
            IEnumerable<EmployeeVM> GetEmployees();
            Task<IEnumerable<EmployeeVM>> GetEmployeesAsync();
            EmployeeVM GetEmployeeDetail(Guid pEmployeeId);
            EmployeeVM AddEmployee(EmployeeVM pEmployee);
            EmployeeVM EditEmployee(EmployeeVM pEmployee);
            void DeleteEmployee(EmployeeVM pEmployee);

        
    }
}

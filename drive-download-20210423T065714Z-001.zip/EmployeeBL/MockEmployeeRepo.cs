﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeBL
{
    public class MockEmployeeRepo : IEmployeeRepository
    {
        List<EmployeeVM> _employees = new List<EmployeeVM>() {
        new EmployeeVM(){ EmployeeId = Guid.NewGuid(), Name="Eena", Email = "eena@danske.com"},
        new EmployeeVM(){ EmployeeId = Guid.NewGuid(), Name="Meena", Email = "meena@danske.com"},
        new EmployeeVM(){ EmployeeId = Guid.NewGuid(), Name="Teena", Email = "teena@danske.com"}
        };

        public EmployeeVM AddEmployee(EmployeeVM pEmployee)
        {
            pEmployee.EmployeeId = Guid.NewGuid();
            _employees.Add(pEmployee);
            return pEmployee;
        }

        public void DeleteEmployee(EmployeeVM pEmployee)
        {
            throw new NotImplementedException();
        }

        public EmployeeVM EditEmployee(EmployeeVM pEmployee)
        {
            throw new NotImplementedException();
        }

        public EmployeeVM GetEmployeeDetail(Guid pEmployeeId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<EmployeeVM> GetEmployees()
        {
            return _employees;
        }

        public Task<IEnumerable<EmployeeVM>> GetEmployeesAsync()
        {
            throw new NotImplementedException();
        }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EmployeeBL
{
    public class EmployeeVM
    {
        [Required(ErrorMessage ="This field is Required")]
        public Guid EmployeeId { get; set; }

        [StringLength(20, ErrorMessage ="Name is not within the permissible length", MinimumLength =5)]
        public string Name { get; set; }

        [EmailAddress(ErrorMessage = "Invalid Email")]
        [EmailDomain(DomainName ="danske.com", ErrorMessage ="Please enter your Danske email address")]
        public string Email { get; set; }

        public string Department { get; set; }
    }
}

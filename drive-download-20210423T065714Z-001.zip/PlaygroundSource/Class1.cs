﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace PlaygroundSource
{
    public class Simple
    {
        public Simple()
        {

        }

        public List<string> GetStrings()
        {
            return new List<string>() { "Eena", "Meena", "Deeka" };
        }

        public bool IsValidAddress(string emailAddress)
        {
            Regex regex = new Regex(@"^[\w0-9._%+-]+@[\w0-9.-]+\.[\w]{2,6}$");
            return regex.IsMatch(emailAddress);
        }

    }
}
